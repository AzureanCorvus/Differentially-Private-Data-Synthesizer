import streamlit as st
from dpsynthesizer import DPSynthesizer
import pandas as pd

# Configure Streamlit
st.set_page_config(page_title="DP Data Synthesizer", layout="wide")
st.title("Differentially Private Data Synthesizer")
st.markdown("""
Generate synthetic datasets with formal privacy guarantees (ε-differential privacy)
""")

# Sidebar controls
with st.sidebar:
    st.header("Privacy Controls")
    epsilon = st.slider("Privacy parameter (ε)", 
                       min_value=0.1, 
                       max_value=5.0, 
                       value=1.0,
                       help="Lower values = stronger privacy")
    
    n_samples = st.number_input("Samples to generate", 
                              min_value=100, 
                              max_value=100000, 
                              value=1000)

# Main content
uploaded_file = st.file_uploader("Upload your CSV file", type=["csv"])

if uploaded_file:
    data = pd.read_csv(uploaded_file)
    st.success(f"Loaded data with {len(data)} records and {len(data.columns)} features")
    
    with st.expander("View original data"):
        st.dataframe(data.head())
    
    if st.button("Generate Synthetic Data", type="primary"):
        synthesizer = DPSynthesizer(epsilon=epsilon)
        
        with st.spinner("Learning private distributions..."):
            synthesizer.fit(data)
            
        synthetic_data = synthesizer.generate(n_samples)
        
        st.subheader("Synthetic Data Preview")
        st.dataframe(synthetic_data.head())
        
        # Download button
        csv = synthetic_data.to_csv(index=False).encode('utf-8')
        st.download_button(
            label="Download as CSV",
            data=csv,
            file_name='synthetic_data.csv',
            mime='text/csv'
        )
        
        # Quick comparison
        st.subheader("Basic Comparison")
        col1, col2 = st.columns(2)
        
        with col1:
            st.metric("Original Records", len(data))
            
        with col2:
            st.metric("Synthetic Records", len(synthetic_data))
else:
    st.info("Please upload a CSV file to get started")