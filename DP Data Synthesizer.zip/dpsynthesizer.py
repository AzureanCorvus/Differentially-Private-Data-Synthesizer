import numpy as np
import pandas as pd
from sklearn.preprocessing import OneHotEncoder
from diffprivlib.tools import histogram

class DPSynthesizer:
    def __init__(self, epsilon=1.0):
        """Initialize synthesizer with privacy budget epsilon"""
        self.epsilon = epsilon
        self.encoder = None
        self.feature_categories = None
        self.dp_histograms = None
        self.numeric_columns = None
        
    def fit(self, data, categorical_columns=None):
        """Learn private data distributions"""
        # Input validation
        if len(data) == 0:
            raise ValueError("Input data cannot be empty")
        if not isinstance(data, pd.DataFrame):
            raise TypeError("Input data must be a pandas DataFrame")
            
        if categorical_columns is None:
            categorical_columns = data.columns.tolist()
            
        # Numerical columns handling
        self.numeric_columns = [col for col in data.columns 
                              if col not in categorical_columns]
        if self.numeric_columns:
            print(f"Note: Numerical columns detected ({', '.join(self.numeric_columns)}). "
                 "These will be ignored in current version.")
            
        # One-hot encode categorical data
        self.encoder = OneHotEncoder(sparse_output=False)
        encoded_data = self.encoder.fit_transform(data[categorical_columns])
        self.feature_categories = self.encoder.categories_
        
        # Get DP histograms for each feature
        self.dp_histograms = []
        privacy_budget = self.epsilon / encoded_data.shape[1]  # Budget splitting
        
        for i in range(encoded_data.shape[1]):
            hist, _ = histogram(encoded_data[:, i], epsilon=privacy_budget)
            self.dp_histograms.append(hist)
            
    def generate(self, n_samples):
        """Generate synthetic data"""
        synthetic_samples = []
        for hist, categories in zip(self.dp_histograms, self.feature_categories):
            # Ensure we have exactly one probability per category
            if len(hist) < len(categories):
                hist = np.pad(hist, (0, len(categories) - len(hist)), 
                             mode='constant', 
                             constant_values=1e-10)
            elif len(hist) > len(categories):
                hist = hist[:len(categories)]
            
            probs = hist / hist.sum()
            probs = np.nan_to_num(probs, nan=1.0/len(categories))
            probs = np.clip(probs, 0, 1)
            probs = probs / probs.sum()
            
            synthetic_samples.append(
                np.random.choice(categories, size=n_samples, p=probs)
            )
            
        return pd.DataFrame(
            np.column_stack(synthetic_samples),
            columns=self.encoder.feature_names_in_
        )